# Harmos Conecta — projeto completo e independente

Fotografia do projeto em 23/11/2026. O pacote pode ser baixado, armazenado, estudado e executado sem acesso ao ChatGPT.

## O que há neste ZIP
- codigo/: fonte React/TypeScript, API Node, conteúdo do chatbot, testes, imagens, fontes, lockfile, configurações Vercel e migrações Supabase.
- supabase/: estrutura restaurável, funções atuais conferidas no banco, políticas/RLS, fotografia JSON dos dados de negócio e contagens.
- vercel/: HTML/JS/CSS da publicação efetivamente servida, metadados da implantação e nomes das variáveis exigidas, sem seus valores secretos.
- widget/: JavaScript completo e exemplo de instalação no site existente.
- SHA256SUMS.txt: hashes para conferir cada arquivo.

A fonte GitHub foi conferida arquivo por arquivo contra o commit 4cd2df279283bdcd29bce6c98470bf24c945acf0. A publicação Vercel de origem corresponde ao commit 37f244c455fccd0d470c4aa014814d03e0e17464; as únicas diferenças de origem eram três documentos, sem diferenças no código executado. O pacote acrescenta licença, avisos de terceiros e auxiliares de restauração/execução independente, identificados na pasta codigo.

## Dados e configurações
No momento da exportação, as tabelas de negócio, o cadastro de usuários Auth e o Storage estavam vazios. Os arrays vazios no snapshot são os dados reais verificados, não dados omitidos de alunos.
Não são incluídos segredos, verificadores de segredos de produção, sessões, allowlist administrativa real ou estado temporário do limitador de requisições. Esses itens são específicos da instalação e devem ser configurados pelo novo operador. Os dados de negócio exportados cobrem os schemas harmos_crm e as tabelas public.harmos_*. Estruturas internas gerenciadas pelo Supabase e pela Vercel não são código do projeto e não constituem parte de um dump físico desses serviços.
As configurações do painel de Auth (Site URL, URLs de retorno, templates e provedores) não foram exportadas pelo conector. Configure-as na instalação nova.

## Restaurar em um Supabase novo
1. Crie um projeto Supabase vazio ou use a distribuição oficial auto-hospedada. É necessário ter Auth, extensões e os papéis anon/authenticated próprios do Supabase.
2. Execute supabase/restaurar-estrutura.sql pelo SQL Editor ou por psql com uma conexão administrativa. Ele contém as três migrações aplicadas, RLS, funções e permissões. Não rode esse arquivo sobre um banco já instalado.
3. Confira supabase/dados-aplicacao.json. As tabelas de negócio estão vazias nesta fotografia, portanto não há INSERTs de dados pessoais para restaurar.
4. Na pasta codigo, ajuste src/client.ts com a URL e a chave publicável do NOVO Supabase. A chave publicável pode estar no frontend; chaves administrativas não.
5. Defina NEW_SUPABASE_URL, NEW_SUPABASE_PUBLISHABLE_KEY e ADMIN_EMAIL no ambiente e execute node scripts/configure-restoration.mjs. Esse comando gera um segredo novo em .env.local e o arquivo bootstrap-private.local.sql com o hash e o e-mail administrativo. Nenhuma credencial de produção foi embutida no ZIP.
6. Execute bootstrap-private.local.sql no banco novo. Cadastre a conta administrativa no aplicativo e confirme o e-mail. Nenhuma senha padrão é fornecida.
7. No Supabase Auth, configure Site URL e URLs de confirmação/recuperação para o domínio escolhido.

## Executar sem Vercel
Na pasta codigo, com Node 22 e a configuração .env.local pronta:

    npm ci
    npm test
    npm run build
    npm start

O servidor opcional usa a porta 3000 e endereço local por padrão. PORT e HOST podem ser definidos pelo operador. Para produção, use um servidor HTTPS/reverse proxy adequado. O banco/Auth continuam no Supabase escolhido pelo operador; também podem ser auto-hospedados com a distribuição oficial.

## Publicar na Vercel
Importe a pasta codigo em um repositório de sua conta e conecte esse repositório a um projeto Vercel. Framework Vite; build npm run build; saída dist; Node 22. Configure SUPABASE_URL, SUPABASE_ANON_KEY e HARMOS_API_SECRET no servidor com os valores da NOVA instalação. Não coloque o segredo em uma variável VITE_. O arquivo vercel.json inclui as rotas da API e do chatbot.

## Instalar o widget no site existente
Use o arquivo widget/instalar-no-site.html. O script de produção atual é:

    <script src="https://harmos-conecta.vercel.app/harmos-widget.js" defer></script>

Se você republicar em outro domínio, substitua a URL do src. O widget deriva a URL do chat desse endereço. Para incorporar em sites diferentes de harmosacademia.com.br e www.harmosacademia.com.br, ajuste a política frame-ancestors no vercel.json.

## Código aberto e limites
Código original sob MIT. Dependências, fonte Inter, marcas, fotografias e perspectivas mantêm seus próprios direitos; veja LICENSE e THIRD_PARTY_NOTICES.md.
O assistente atual usa conteúdo guiado; não requer API de IA. O WhatsApp é aberto com resumo para confirmação do visitante. Não há integração Meta, disparos, reservas reais ou cobrança no chatbot. O ZIP contém o projeto implementado, não módulos futuros apenas propostos.
